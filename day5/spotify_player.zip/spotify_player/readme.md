# Spotify Player

This is the skeleton to start implementing the Spotify Player!

Happy coding!